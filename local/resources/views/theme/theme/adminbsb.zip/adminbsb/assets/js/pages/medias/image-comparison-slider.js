﻿(function ($) {
    'use strict';
    $(function () {
        $('.cocoen').cocoen();
    });
}(jQuery))
